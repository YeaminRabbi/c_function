#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>



int selectmenu()
{
    ///add your menu bar lines here
    printf("----------------------------Menu Bar------------------------------------ \n");
    printf("Press 1  >> to calculate Factorial of an integer\n");
    printf("Press 2  >> to formatted Output\n");
    printf("Press 3  >> to quadratic Roots\n");
    printf("Press 4  >> to equation Solver\n");
    printf("Press 5  >> to guessing Game\n");
    printf("Press 6  >> to diamond Generator\n");
    printf("Press 7  >> to all Prime Generator\n");
    printf("Press 8  >> to fibonacci Generator\n");
    printf("Press 9  >> to palindrome Check\n");
    printf("Press 10 >> to array Merging\n");
    printf("Press 11 >> to matrix Symmetry Check\n");
    printf("Press 0  >> to Exit\n");
    printf("------------------------------------------------------------------------ \n");

    int choice;
    printf("Please enter your choice: ");
    scanf("%d",&choice);

    return choice;
}

void calculateFactorial()
{
    int number;
    printf("Please enter the number: ");
    scanf("%d",&number);

    if(number<0)
    {
        printf("Invalid number. \n");
    }
    else if(number==0)
    {
        printf("The factorial is: 1\n");
    }
    else
    {
        int factresult=1;

        int x;
        for(x=1; x<=number; x++)
        {
            factresult=factresult*x;
        }

        printf("The factorial is: %d \n",factresult);
    }



    printf("\n");
    system("pause");
    system("cls");
}



void formattedOutput()
{
    int num;
    printf("Input:");
    scanf("%d", &num);
    int num1=num;
    int binary=0;
    int r,i=1;

    while (num1!=0)
    {
        r=num1%2;
        num1/=2;
        binary= binary + (r*i);
        i=i*10;
    }
    printf("Integer: %d\nOctal: %o\nHexadecimal: %X", num,num, num);
    printf("\nBinary: %d", binary);

    printf("\n");
    system("pause");
    system("cls");
}


void quadraticRoots()
{
    int a,b,c;
    printf("input a b c: ");
    scanf("%d %d %d", &a, &b, &c);

    float output;
    float output1;
    float output2;
    float check= (b*b)- (4*a*c);

    if(check<0)
        printf("Complex Roots");
    else if(check==0)
    {
        output= -b / (2*a);
        printf("Single Root is: %d", output);
    }
    else if(check>=0)
    {
        output1=(-b+sqrt((b*b)-(4*a*c))) / (2*a);
        output2=(-b-sqrt((b*b)-(4*a*c))) / (2*a);

        printf("First Root: %.2f\ Second Root: %.2f", output1,output2);
    }

    printf("\n");
    system("pause");
    system("cls");
}

void equationSolver()
{
    int a1,b1,c1;
    int a2,b2,c2;
    printf("Input: a1 b1 c1: ");
    scanf("%d %d %d", &a1, &b1, &c1);
    printf("Input: a2 b2 c2: ");
    scanf("%d %d %d", &a2, &b2, &c2);

    if(((a1*b2)-(a2*b1))==0)
    {
        printf("Parallel Lines and No intersection points");
    }
    else
    {
        int x,y;

        x=((b1*c2)-(b2*c1)) / ((a1*b2)-(a2*b1));
        y=((c1*a2)-(c2*a1)) / ((a1*b2)-(a2*b1));
        printf("X= %d\tY= %d", x,y);
    }

    printf("\n");
    system("pause");
    system("cls");
}


void guessingGame()
{
    int randnum;
    srand(time(NULL));
    randnum=rand()%11;

    int i=1;
    int guess;
    while(i!=6)
    {

        printf("\nInput: ");
        scanf("%d", &guess);

        if((i<0 || i==6) || (guess<randnum))
        {
            printf("Trail Number:%d and Guess a smaller value",i);
        }
        else if((i<0 || i==6) || (guess>randnum))
        {
            printf("Trail Number: %d and Guess a smaller value",i);
        }
        else if((i<0 || i==6) || (guess==randnum))
        {
            printf("Trail Number: %d and You won using 6 guesses",i);
        }
        else if(i>6)
        {
            printf("You lose");
            break;
        }

        i++;
        printf("\n");
    }

    printf("\n");
    system("pause");
    system("cls");
}



void diamondGenerator()
{
    int n;
    while(1)
    {
        printf("Input: ");
        scanf("%d", &n);

        if(n%2!=0)
            break;

        else
            printf("Invalid Input\n");
    }

    int sp, st,row, space =1;
    space=n-1;
    for(row=1; row<=n; row++)
    {
        for(sp=1; sp<=space; sp++)
        {
            printf(" ");
        }

        space--;

        for(st=1; st<=2*row-1; st++)
        {
            printf("*");
        }

        printf("\n");
    }

    space=1;

    for(row=1; row<=n-1; row++)
    {
        for(sp=1; sp<=space; sp++)
        {
            printf(" ");
        }

        space++;

        for(st=1; st<=2*(n-row)-1; st++)
        {
            printf("*");
        }

        printf("\n");
    }

    printf("\n");
    system("pause");
    system("cls");
}




void allPrimeGenerator()
{
    int num1, num2;
    printf("Input Range: ");
    scanf("%d %d", &num1, &num2);

    int max =(num1 > num2)? num1 : num2;
    int min =(num1 < num2)? num1 : num2;

    int i,j,flag;
    for(i=min; i<=max; i++)
    {
        flag=0;
        for(j=2; j<=i/2; j++)
        {
            if(i%j == 0)
            {
                flag++;
                break;
            }
        }
        if(flag==0)
        {
            if(i!=1)
            {
                printf("%d ", i);
            }
        }
    }

    printf("\n");
    system("pause");
    system("cls");

}



void fibonacciGenerator()
{
    int n;
    printf("Input n: ");
    scanf("%d", &n);
    printf("The series: ");
    int a=0,b=1,c=0,i;
    for(i=1; i<=n; i++)
    {
        printf("%d ",c);
        a=b;
        b=c;
        c=a+b;
    }

    printf("\n");
    system("pause");
    system("cls");
}


void palindromeCheck()
{
    int n;
    printf("Input Number: ");
    scanf("%d", &n);
    int n1=n;
    int rev=0;
    int remain;
    while(n1!=0)
    {
        remain=n1%10;
        rev= rev*10 + remain;
        n1=n1/10;
    }

    if(rev!=n)
        printf("No");
    else if (rev==n)
        printf("yes");

    printf("\n");
    system("pause");
    system("cls");
}

void arrayMerging()
{
    int sz1;
    scanf("%d", &sz1);
    int arr1[sz1];
    int i;
    for(i=0; i<sz1; i++)
    {
        scanf("%d", &arr1[i]);
    }
    int sz2;
    scanf("%d", &sz2);
    int arr2[sz2];
    for(i=0; i<sz2; i++)
    {
        scanf("%d", &arr2[i]);
    }

    int sz3=sz1+sz2;
    int arr3[sz3];
    int k=0;
    for(i=0; i<sz3; i++)
    {
        if(i>sz1-1)
        {
            arr3[i]=arr2[k];
            k++;
        }
        else
            arr3[i]=arr1[i];
    }


    int j;
    for(i=0; i<sz3; i++)
    {
        for(j=i+1; j<sz3;)
        {
            if(arr3[i]==arr3[j])
            {
                for(k=j; k<sz3; k++)
                {
                    arr3[k]=arr3[k+1];
                }
                sz3--;
            }
            else
                j++;
        }
    }

    printf("Final Output:");
    for(i=0; i<sz3; i++)
    {
        printf("%d ", arr3[i]);
    }

    printf("\n");
    system("pause");
    system("cls");
}



void matrixSymmetryCheck()
{
    int n;
    printf("Input Size: ");
    scanf("%d", &n);

    int a[n][n], b[n][n];
    int i,j;
    printf("Input Matrix Elements:\n");
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            scanf("%d", &a[i][j]);
        }
    }

    //Transposing the Inputted Matrix
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            b[i][j]=a[j][i];
        }
    }

    //Checking the Inputted Matrix is Symmetric or not
    int flag=1;
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            if(a[i][j]!=b[i][j])
                flag=0;
        }
    }

    if(flag==1)
        printf("Yes Symmetric Matrix");
    else if(flag==0)
        printf("Not a Symmetric");

    printf("\n");
    system("pause");
    system("cls");

}

int main()
{

    printf("Starting the program: \n");
    while(1)
    {
        ///add conditions for different choices here
        int choice=selectmenu();
        if(choice==1)
        {
            calculateFactorial();
        }
        else if(choice==2)
        {
            formattedOutput();
        }
        else if(choice==3)
        {
            quadraticRoots();
        }
        else if(choice==4)
        {
            equationSolver();
        }
        else if(choice==5)
        {
            guessingGame();
        }
        else if(choice==6)
        {
            diamondGenerator();
        }
        else if(choice==7)
        {
            allPrimeGenerator();
        }
        else if(choice==8)
        {
            fibonacciGenerator();
        }
        else if(choice==9)
        {
            palindromeCheck();
        }
        else if(choice==10)
        {
            arrayMerging();
        }
        else if(choice==11)
        {
            matrixSymmetryCheck();
        }
        else if(choice==0)
        {
            printf("Exiting from the program ... ... ... ... \n");
            break;
        }
    }
    return 0;

}
